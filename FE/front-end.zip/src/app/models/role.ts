export class Role {
    id: number;
    code: string;
    name: string;
}