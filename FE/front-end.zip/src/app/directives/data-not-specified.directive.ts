import { Directive } from '@angular/core';

@Directive({
  selector: '[appDataNotSpecified]'
})
export class DataNotSpecifiedDirective {

  constructor() { }

}
