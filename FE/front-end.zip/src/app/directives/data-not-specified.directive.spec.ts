import { DataNotSpecifiedDirective } from './data-not-specified.directive';

describe('DataNotSpecifiedDirective', () => {
  it('should create an instance', () => {
    const directive = new DataNotSpecifiedDirective();
    expect(directive).toBeTruthy();
  });
});
